package com.zt.shareextend;

import androidx.core.content.FileProvider;

public class ShareExtendProvider extends FileProvider {
}
